package com.inmobiliaria.comprobante.gestion_comprobantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionComprobantesApplicationTests {

	@Test
	void contextLoads() {
	}

}
